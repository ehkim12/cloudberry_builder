-- sql for gpcheckcat -A
create user wolf login password 'foo';
