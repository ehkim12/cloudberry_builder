
extern const char *orafce_scan_keyword(const char *text, int *keycode);
