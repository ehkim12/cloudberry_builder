SELECT pg_extension_config_dump('utl_file.utl_file_dir', '');
