ALTER FUNCTION oracle.remainder(smallint, smallint) STRICT;
ALTER FUNCTION oracle.remainder(int, int) STRICT;
ALTER FUNCTION oracle.remainder(bigint, bigint) STRICT;
ALTER FUNCTION oracle.remainder(numeric, numeric) STRICT;
