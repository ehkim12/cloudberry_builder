ALTER FUNCTION dbms_random.string(opt text, len int) VOLATILE;
