DROP ROLE IF EXISTS regress_super_user;
DROP ROLE IF EXISTS regress_normal_user;
DROP EXTENSION pg_hint_plan;
