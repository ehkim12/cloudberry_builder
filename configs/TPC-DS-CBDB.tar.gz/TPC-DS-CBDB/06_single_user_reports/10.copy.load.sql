COPY tpcds_reports.load FROM :LOGFILE WITH DELIMITER '|';
