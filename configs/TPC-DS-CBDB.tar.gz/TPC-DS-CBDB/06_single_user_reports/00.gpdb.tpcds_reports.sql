DROP SCHEMA IF EXISTS tpcds_reports CASCADE;
CREATE SCHEMA tpcds_reports;
