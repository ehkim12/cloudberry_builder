COPY tpcds_reports.compile_tpcds FROM :LOGFILE WITH DELIMITER '|';
