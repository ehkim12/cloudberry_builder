COPY tpcds_reports.init FROM :LOGFILE WITH DELIMITER '|';
