COPY tpcds_testing.sql FROM :LOGFILE WITH DELIMITER '|';
