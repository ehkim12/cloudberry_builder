INSERT INTO tpcds.reason SELECT * FROM ext_tpcds.reason;
